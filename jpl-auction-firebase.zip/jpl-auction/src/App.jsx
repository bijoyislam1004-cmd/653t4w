import {useEffect,useState} from "react";
import {doc,collection,onSnapshot,setDoc,updateDoc,deleteDoc,runTransaction,getDoc} from "firebase/firestore";
import {signInWithEmailAndPassword,signOut,onAuthStateChanged} from "firebase/auth";
import {auth,db} from "./firebase";

const M=n=>"৳"+Number(n||0).toLocaleString("en-IN");
const DS={leagueName:"JANKHALI PREMIER LEAGUE",budget:2000,inc:50,categories:["A","B","C"],rules:""};
const DA={status:"idle",playerId:null,bid:0,bidder:null,bidding:false,history:[]};
const sd=doc(db,"auction/state"),ss=doc(db,"settings/main");
const useCol=n=>{const[a,s]=useState(null);useEffect(()=>onSnapshot(collection(db,n),q=>s(q.docs.map(d=>({id:d.id,...d.data()})))),[n]);return a};
const useDoc=(p,d)=>{const[a,s]=useState(d);useEffect(()=>onSnapshot(doc(db,p),x=>x.exists()&&s({...d,...x.data()})),[p]);return a};
const B=({c="bg-amber-500 text-black",className="",...p})=><button {...p} className={`rounded-lg px-4 py-2.5 font-bold disabled:opacity-40 ${c} ${className}`}/>;
const I=p=><input {...p} className="rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 w-full min-w-0"/>;
const C=({t,children})=><section className="rounded-2xl bg-slate-900/80 border border-slate-800 p-4 mb-4">{t&&<h2 className="font-bold text-amber-400 mb-3">{t}</h2>}{children}</section>;
const Tbl=({h,rows})=><div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr>{h.map(x=><th key={x} className="text-left p-2 text-slate-400">{x}</th>)}</tr></thead><tbody>{rows.map((r,i)=><tr key={i} className="border-t border-slate-800">{r.map((c,j)=><td key={j} className="p-2">{c}</td>)}</tr>)}</tbody></table></div>;
const img=(f,cb)=>{const r=new FileReader();r.onload=()=>{const i=new Image();i.onload=()=>{const c=document.createElement("canvas"),k=Math.min(1,320/Math.max(i.width,i.height));c.width=i.width*k;c.height=i.height*k;c.getContext("2d").drawImage(i,0,0,c.width,c.height);cb(c.toDataURL("image/jpeg",.7))};i.src=r.result};r.readAsDataURL(f)};

export default function App(){
 const[u,setU]=useState(undefined),[me,setMe]=useState(null);
 useEffect(()=>onAuthStateChanged(auth,async x=>{setU(x);setMe(null);if(x){const d=await getDoc(doc(db,"users",x.uid));setMe(d.exists()?d.data():{})}}),[]);
 if(u===undefined||(u&&!me))return <div className="p-8">Loading…</div>;
 if(!u)return <Login/>;
 if(!me.role)return <div className="p-8 space-y-3"><p>No role assigned. Create a Firestore document users/{u.uid} (see README).</p><B onClick={()=>signOut(auth)}>Log out</B></div>;
 return <Main me={me}/>}

function Login(){const[e,setE]=useState(""),[p,setP]=useState(""),[er,setEr]=useState("");
 return <div className="min-h-screen grid place-items-center p-4"><form onSubmit={async x=>{x.preventDefault();try{await signInWithEmailAndPassword(auth,e,p)}catch(z){setEr(z.message)}}} className="w-full max-w-sm space-y-3 rounded-2xl bg-slate-900 p-6 border border-slate-800">
 <h1 className="text-2xl font-black text-amber-400">🏏 JANKHALI PREMIER LEAGUE</h1><div className="text-slate-400">Player Auction · Login</div>
 <I type="email" placeholder="Email" value={e} onChange={x=>setE(x.target.value)}/><I type="password" placeholder="Password" value={p} onChange={x=>setP(x.target.value)}/>
 {er&&<div className="text-red-400 text-sm">{er}</div>}<B className="w-full">Login</B></form></div>}

function Main({me}){
 const S=useDoc("settings/main",DS),A=useDoc("auction/state",DA),T=useCol("teams"),players=useCol("players")||[],hist=useCol("history")||[];
 const teams=(T||[]).slice().sort((a,b)=>a.id.localeCompare(b.id));
 const isA=me.role==="admin",[view,setView]=useState("live"),[sel,setSel]=useState(null),[cat,setCat]=useState("");
 const[form,setForm]=useState({name:"",photo:"",category:"",base:100}),[f,setF]=useState({q:"",s:"",t:"",c:""});
 const cur=players.find(p=>p.id===A.playerId),tm=id=>teams.find(t=>t.id===id),left=t=>t.budget-t.spent;
 const sq=id=>players.filter(p=>p.teamId===id&&p.status==="sold");
 useEffect(()=>{if(isA&&T&&!T.length)(async()=>{await setDoc(ss,DS);await setDoc(sd,DA);for(let i=1;i<=4;i++)await setDoc(doc(db,"teams","t"+i),{name:"TEAM "+i,logo:"",budget:DS.budget,spent:0})})()},[T]);

 const bid=tid=>runTransaction(db,async t=>{
  const st=(await t.get(sd)).data(),tt=(await t.get(doc(db,"teams",tid))).data(),se=(await t.get(ss)).data();
  if(st.status!=="live"||!st.bidding||!st.playerId)throw Error("Bidding is not open");
  if(st.bidder===tid)throw Error("You already lead this bid");
  const amt=st.bidder?st.bid+se.inc:st.bid;
  if(amt>tt.budget-tt.spent)throw Error("Insufficient budget");
  t.update(sd,{bid:amt,bidder:tid,history:[...st.history,{team:tt.name,amount:amt}]})}).catch(e=>alert(e.message));
 const pick=async id=>{if(A.status!=="live")return alert("Start or resume the auction first");const p=players.find(x=>x.id===id);
  if(p.status==="sold")return;if(p.status==="unsold")await updateDoc(doc(db,"players",id),{status:"pending"});
  await updateDoc(sd,{playerId:id,bid:p.base,bidder:null,bidding:false,history:[]})};
 const next=()=>{const p=players.find(x=>x.status==="pending");p?pick(p.id):alert("No pending players")};
 const sold=async()=>{if(!cur||!A.bidder)return alert("No valid highest bidder");
  if(!confirm(`Sell ${cur.name} to ${tm(A.bidder).name} for ${M(A.bid)}?`))return;
  await runTransaction(db,async t=>{const st=(await t.get(sd)).data(),pr=doc(db,"players",st.playerId),p=(await t.get(pr)).data(),tr=doc(db,"teams",st.bidder),tt=(await t.get(tr)).data();
   if(p.status==="sold"||!st.bidder)throw Error("Already sold or no bidder");
   if(st.bid>tt.budget-tt.spent)throw Error("Budget exceeded");
   t.update(pr,{status:"sold",teamId:st.bidder,price:st.bid,soldAt:Date.now()});t.update(tr,{spent:tt.spent+st.bid});
   t.set(doc(collection(db,"history")),{name:p.name,category:p.category,base:p.base,price:st.bid,teamId:st.bidder,status:"SOLD",at:Date.now()});
   t.update(sd,{...DA,status:st.status})}).catch(e=>alert(e.message))};
 const unsold=async()=>{if(!cur||!confirm("Mark "+cur.name+" UNSOLD?"))return;
  await updateDoc(doc(db,"players",cur.id),{status:"unsold"});
  await setDoc(doc(collection(db,"history")),{name:cur.name,category:cur.category,base:cur.base,price:0,teamId:"",status:"UNSOLD",at:Date.now()});
  await updateDoc(sd,{...DA,status:A.status})};
 const savePlayer=async()=>{if(!form.name.trim())return;const d={name:form.name.trim(),photo:form.photo,category:form.category||S.categories[0],base:+form.base||0};
  form.id?await updateDoc(doc(db,"players",form.id),d):await setDoc(doc(collection(db,"players")),{...d,status:"pending",teamId:"",price:0});
  setForm({name:"",photo:"",category:"",base:100})};
 const upS=x=>updateDoc(ss,x),upT=(id,x)=>updateDoc(doc(db,"teams",id),x);

 const live=()=><div className="text-center">
  <h1 className="text-2xl sm:text-5xl font-black text-amber-400">{S.leagueName}</h1><div className="tracking-[.4em] text-slate-300 mb-4">PLAYER AUCTION</div>
  {cur?<>
   <div className="mx-auto w-52 h-52 sm:w-72 sm:h-72 rounded-3xl overflow-hidden border-4 border-amber-400 bg-slate-800 grid place-items-center">{cur.photo?<img src={cur.photo} className="w-full h-full object-cover"/>:<span className="text-8xl">🏏</span>}</div>
   <div className="text-4xl sm:text-6xl font-black mt-4">{cur.name}</div>
   <div className="text-slate-300 text-lg">Category {cur.category} · Base price {M(cur.base)}</div>
   <div className="mt-4 text-sm text-slate-400">CURRENT BID</div><div key={A.bid} className="pop text-7xl sm:text-9xl font-black text-amber-400">{M(A.bid)}</div>
   <div className="text-sm text-slate-400 mt-2">HIGHEST BIDDER</div><div className="text-3xl sm:text-5xl font-black">{A.bidder?tm(A.bidder)?.name:"—"}</div>
   {(!A.bidding||A.status!=="live")&&<div className="mt-3 text-red-400 font-bold">{A.status==="paused"?"AUCTION PAUSED":"BIDDING NOT OPEN YET"}</div>}
  </>:<div className="py-16 text-2xl text-slate-300">{A.status==="ended"?"AUCTION COMPLETE":A.status==="idle"?"Auction has not started":"Waiting for the next player…"}</div>}
  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-6">{teams.map(t=><div key={t.id} className={`rounded-xl p-3 border-2 ${A.bidder===t.id?"border-amber-400 bg-amber-400/10":"border-slate-800 bg-slate-900"}`}>
   {t.logo&&<img src={t.logo} className="h-10 mx-auto mb-1 rounded"/>}<div className="font-bold">{t.name}</div><div className="text-xl font-black">{M(left(t))}</div><div className="text-xs text-slate-400">Remaining</div></div>)}</div>
  <C t="LIVE BID HISTORY"><div className="space-y-1 text-left">{[...A.history].reverse().map((h,i)=><div key={i} className="flex justify-between"><span>{h.team}</span><b>{M(h.amount)}</b></div>)}{!A.history.length&&<div className="text-slate-500">No bids yet</div>}</div></C></div>;

 const myTeam=()=>{const t=tm(me.teamId);if(!t)return <C>Team not found.</C>;const s=sq(t.id);
  return <><C><div className="text-center space-y-3"><h2 className="text-3xl font-black">{t.name}</h2>
   {cur?<div>Now: <b>{cur.name}</b> ({cur.category}) · Bid <b className="text-amber-400">{M(A.bid)}</b> · {A.bidder?tm(A.bidder)?.name:"no bids"}</div>:<div className="text-slate-400">No player on the block</div>}
   <B className="w-full text-2xl py-5" disabled={!cur||!A.bidding||A.status!=="live"||A.bidder===t.id||(A.bidder?A.bid+S.inc:A.bid)>left(t)} onClick={()=>bid(t.id)}>BID {cur?M(A.bidder?A.bid+S.inc:A.bid):""}</B></div></C>
   <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">{[["Starting",M(t.budget)],["Spent",M(t.spent)],["Remaining",M(left(t))],["Players",s.length]].map(([a,b])=><div key={a} className="rounded-xl bg-slate-900 p-3 text-center"><div className="text-xs text-slate-400">{a}</div><div className="text-xl font-black">{b}</div></div>)}</div>
   <C t="Squad"><Tbl h={["Player","Category","Price"]} rows={s.map(p=>[p.name,p.category,M(p.price)])}/></C></>};

 const squads=()=><><div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">{teams.map(t=><button key={t.id} onClick={()=>setSel(t.id)} className={`text-left rounded-xl p-4 border-2 bg-slate-900 ${sel===t.id?"border-amber-400":"border-slate-800"}`}>
  <div className="flex items-center gap-3">{t.logo&&<img src={t.logo} className="h-12 rounded"/>}<b className="text-xl">{t.name}</b></div><div className="text-sm text-slate-300 mt-2">Remaining {M(left(t))} · Players {sq(t.id).length} · Spent {M(t.spent)}</div></button>)}</div>
  {sel&&tm(sel)&&<C t={tm(sel).name+" squad"}><Tbl h={["Player","Category","Price"]} rows={sq(sel).map(p=>[p.name,p.category,M(p.price)])}/></C>}</>;

 const history=()=>{const rows=hist.filter(h=>(!f.s||h.status===f.s)&&(!f.t||h.teamId===f.t)&&(!f.c||h.category===f.c)&&h.name.toLowerCase().includes(f.q.toLowerCase())).sort((a,b)=>b.at-a.at);
  return <C t="Auction History"><div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3"><I placeholder="Search player" value={f.q} onChange={e=>setF({...f,q:e.target.value})}/>
   <select className="rounded-lg bg-slate-800 p-2" value={f.s} onChange={e=>setF({...f,s:e.target.value})}><option value="">All status</option><option>SOLD</option><option>UNSOLD</option></select>
   <select className="rounded-lg bg-slate-800 p-2" value={f.t} onChange={e=>setF({...f,t:e.target.value})}><option value="">All teams</option>{teams.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select>
   <select className="rounded-lg bg-slate-800 p-2" value={f.c} onChange={e=>setF({...f,c:e.target.value})}><option value="">All categories</option>{S.categories.map(c=><option key={c}>{c}</option>)}</select></div>
   <Tbl h={["Player","Cat","Base","Sold price","Team","Status","Time"]} rows={rows.map(h=>[h.name,h.category,M(h.base),h.price?M(h.price):"—",tm(h.teamId)?.name||"—",h.status,new Date(h.at).toLocaleString()])}/></C>};

 const admin=()=>{const sold_=players.filter(p=>p.status==="sold"),uns=players.filter(p=>p.status==="unsold"),pen=players.filter(p=>p.status==="pending"),spent=teams.reduce((a,t)=>a+t.spent,0);
  return <>
  <C t={`Auction control · ${A.status.toUpperCase()}`}>
   <div className="flex flex-wrap gap-2 mb-3"><B disabled={A.status==="live"||A.status==="paused"} onClick={()=>updateDoc(sd,{status:"live"})}>Start Auction</B>
    <B disabled={A.status!=="live"} onClick={()=>updateDoc(sd,{status:"paused"})}>Pause</B><B disabled={A.status!=="paused"} onClick={()=>updateDoc(sd,{status:"live"})}>Resume</B>
    <B c="bg-slate-700" onClick={()=>confirm("End the auction?")&&updateDoc(sd,{status:"ended"})}>End</B></div>
   <div className="flex flex-wrap gap-2 mb-3"><B c="bg-sky-500 text-black" onClick={next}>Next Player</B><B c="bg-sky-500 text-black" disabled={!cur||A.status!=="live"} onClick={()=>updateDoc(sd,{bidding:true})}>Start Bidding</B>
    <B c="bg-green-500 text-black" disabled={!cur||!A.bidder} onClick={sold}>🔨 SOLD</B><B c="bg-red-500" disabled={!cur} onClick={unsold}>❌ UNSOLD</B></div>
   <div className="mb-3 text-sm">Select player: <select className="rounded-lg bg-slate-800 p-2 max-w-full" value="" onChange={e=>e.target.value&&pick(e.target.value)}><option value="">Choose…</option>{pen.map(p=><option key={p.id} value={p.id}>{p.name} ({p.category}) {M(p.base)}</option>)}</select></div>
   <div className="flex flex-wrap gap-2 items-center text-sm">Increment {M(S.inc)}: {[10,20,50,100].map(v=><B key={v} c={S.inc===v?"bg-amber-500 text-black":"bg-slate-700"} onClick={()=>upS({inc:v})}>{v}</B>)}<div className="w-28"><I type="number" placeholder="Custom" onBlur={e=>+e.target.value>0&&upS({inc:+e.target.value})}/></div></div>
   {uns.length>0&&<div className="mt-3"><div className="text-sm text-slate-400 mb-1">Unsold players (re-auction)</div><div className="flex flex-wrap gap-2">{uns.map(p=><B key={p.id} c="bg-slate-700" onClick={()=>pick(p.id)}>↺ {p.name}</B>)}</div></div>}</C>
  <C t="Dashboard"><div className="grid grid-cols-2 sm:grid-cols-3 gap-3">{[["Total players",players.length],["Sold",sold_.length],["Unsold",uns.length],["Remaining",pen.length],["Teams",teams.length],["Money spent",M(spent)]].map(([a,b])=><div key={a} className="rounded-xl bg-slate-800 p-3 text-center"><div className="text-xs text-slate-400">{a}</div><div className="text-2xl font-black">{b}</div></div>)}</div>
   <div className="mt-3 space-y-2">{teams.map(t=><div key={t.id}><div className="flex justify-between text-sm"><span>{t.name} · {sq(t.id).length} players · spent {M(t.spent)}</span><span>left {M(left(t))}</span></div><div className="h-2 rounded bg-slate-800"><div className="h-2 rounded bg-amber-400" style={{width:Math.min(100,t.spent/(t.budget||1)*100)+"%"}}/></div></div>)}</div></C>
  <C t="Teams">{teams.map(t=><details key={t.id} className="mb-3 rounded-xl bg-slate-800 p-3"><summary className="cursor-pointer font-bold">{t.name} · left {M(left(t))} · {sq(t.id).length} players</summary>
   <div className="grid sm:grid-cols-3 gap-2 mt-3">{t.logo&&<img src={t.logo} className="h-12 rounded"/>}<I defaultValue={t.name} onBlur={e=>upT(t.id,{name:e.target.value})}/><I type="number" defaultValue={t.budget} onBlur={e=>upT(t.id,{budget:+e.target.value||0})}/></div>
   <input className="mt-2 text-sm" type="file" accept="image/*" onChange={e=>e.target.files[0]&&img(e.target.files[0],d=>upT(t.id,{logo:d}))}/>
   <Tbl h={["Player","Cat","Price"]} rows={sq(t.id).map(p=>[p.name,p.category,M(p.price)])}/></details>)}</C>
  <C t="Players"><div className="grid sm:grid-cols-4 gap-2"><I placeholder="Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
   <select className="rounded-lg bg-slate-800 p-2" value={form.category||S.categories[0]} onChange={e=>setForm({...form,category:e.target.value})}>{S.categories.map(c=><option key={c}>{c}</option>)}</select>
   <I type="number" placeholder="Base price" value={form.base} onChange={e=>setForm({...form,base:e.target.value})}/><B onClick={savePlayer}>{form.id?"Save":"Add player"}</B></div>
   <input className="my-2 text-sm" type="file" accept="image/*" onChange={e=>e.target.files[0]&&img(e.target.files[0],d=>setForm({...form,photo:d}))}/>
   <Tbl h={["","Name","Cat","Base","Status",""]} rows={players.map(p=>[p.photo?<img src={p.photo} className="h-8 w-8 rounded object-cover"/>:"🏏",p.name,p.category,M(p.base),p.status,p.status==="sold"?"locked":<span className="flex gap-1"><B c="bg-slate-700" onClick={()=>setForm({id:p.id,name:p.name,photo:p.photo,category:p.category,base:p.base})}>Edit</B><B c="bg-red-500" disabled={p.id===A.playerId} onClick={()=>confirm("Delete "+p.name+"?")&&deleteDoc(doc(db,"players",p.id))}>Del</B></span>])}/></C>
  <C t="Settings"><div className="grid sm:grid-cols-2 gap-2"><I defaultValue={S.leagueName} onBlur={e=>upS({leagueName:e.target.value})}/><div className="flex gap-2"><I type="number" defaultValue={S.budget} onBlur={e=>upS({budget:+e.target.value||0})}/><B onClick={()=>confirm("Set every team budget to "+M(S.budget)+"?")&&teams.forEach(t=>upT(t.id,{budget:S.budget}))}>Apply</B></div></div>
   <div className="text-sm text-slate-400 mt-2">Teams: 4 · Currency: BDT ৳</div>
   <div className="flex flex-wrap gap-2 my-2">{S.categories.map(c=><B key={c} c="bg-slate-700" onClick={()=>confirm("Remove category "+c+"?")&&upS({categories:S.categories.filter(x=>x!==c)})}>{c} ✕</B>)}</div>
   <div className="flex gap-2"><I placeholder="New category" value={cat} onChange={e=>setCat(e.target.value)}/><B onClick={()=>{if(cat.trim()&&!S.categories.includes(cat.trim())){upS({categories:[...S.categories,cat.trim()]});setCat("")}}}>Add</B></div>
   <textarea className="w-full mt-3 rounded-lg bg-slate-800 border border-slate-700 p-2" rows="3" placeholder="Auction rules" defaultValue={S.rules} onBlur={e=>upS({rules:e.target.value})}/></C></>};

 const tabs=[["live","Live"],["squads","Squads"],["history","History"],isA?["admin","Admin"]:["team","My Team"]];
 return <div className="max-w-5xl mx-auto p-3 sm:p-6"><div className="flex flex-wrap gap-2 mb-4 sticky top-0 z-10 bg-slate-950/90 p-2 rounded-xl">{tabs.map(([k,l])=><B key={k} c={view===k?"bg-amber-500 text-black":"bg-slate-800"} onClick={()=>setView(k)}>{l}</B>)}<B c="bg-slate-800 ml-auto" onClick={()=>signOut(auth)}>Logout</B></div>
  {view==="live"&&live()}{view==="squads"&&squads()}{view==="history"&&history()}{view==="admin"&&isA&&admin()}{view==="team"&&!isA&&myTeam()}</div>}
